export {};
//# sourceMappingURL=getProgress.test.d.ts.map