export {};
//# sourceMappingURL=getProgressPercent.test.d.ts.map